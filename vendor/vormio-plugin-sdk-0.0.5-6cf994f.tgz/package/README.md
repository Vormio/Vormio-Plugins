# @vormio/plugin-sdk

为 Vormio 编写插件所需的 manifest schema、运行时辅助函数与打包命令。本包随 Vormio-Core 同版本发布（当前 0.0.5），以 MIT 许可证发布到 npm：`npm install @vormio/plugin-sdk@0.0.5`。

插件契约版本 `apiVersion: 1`。开发期（0.0.x）不承诺跨版本兼容：宿主只加载与自己相同 `apiVersion` 的插件。

## 插件能做什么

插件为它声明的格式提供三种能力，彼此独立，声明一种不会获得另外两种：

| 扩展点 | 运行位置                               | 结果                                                                                     |
| ------ | -------------------------------------- | ---------------------------------------------------------------------------------------- |
| 缩略图 | 隐藏的沙箱页面，可以用 Canvas 与 WebGL | 一张 PNG，最长边不超过宿主给出的 `maxEdge`（目前 320），宿主再限制在 512×512、4 MiB 以内 |
| 查看器 | 叠在 Vormio 查看区上的沙箱页面         | 只读地显示文件，用户可以在其中交互                                                       |
| 分析器 | 隐藏的沙箱页面                         | 一份组成报告：文件内部的子资源、它引用的文件和诊断，见[分析器](#分析器)                  |

插件在资源库中启用后才会运行。每个插件有自己的内存分区：

- 不能访问网络、`file:` 或其他插件。
- 没有 Node，不能用 `eval`。
- 可以使用 WebAssembly 与 Worker。
- 只能读取宿主绑定给它的文件，以及同一关联文件夹中、扩展名在 `companionFormats` 里的配套文件。
- 不能修改任何文件。

## 包结构

一个插件是一个目录：根目录下的 `manifest.json` 加上构建好的静态文件。

```json
{
  "apiVersion": 1,
  "id": "acme.model-viewer",
  "version": "0.1.0",
  "name": "模型查看器",
  "description": "示例。",
  "contributions": {
    "thumbnails": [
      {
        "id": "model",
        "entry": "thumbnail.html",
        "formats": ["gltf", "glb"],
        "companionFormats": ["bin", "png", "jpg"]
      }
    ],
    "viewers": [
      {
        "id": "model",
        "entry": "viewer.html",
        "formats": ["gltf", "glb"],
        "companionFormats": ["bin", "png", "jpg"]
      }
    ],
    "analyzers": [{ "id": "model", "entry": "analyzer.html", "formats": ["gltf", "glb"] }]
  }
}
```

- `thumbnails`、`viewers`、`analyzers` 都可以省略，但至少要有一个扩展点；每种最多 8 个，ID 在同一种内不能重复。

- `id` 为 `发布者.名称`，只用小写字母、数字与连字符；`vormio` 发布者保留给宿主。
- `formats`、`companionFormats` 是不带点的小写扩展名，不能用通配符。
- `entry` 是包内的 HTML 文件。页面带有严格的内容安全策略，脚本必须放在单独的文件里，不能内联。
- 未知字段会被拒绝。

**允许的文件**：`html js mjs css json wasm png jpg jpeg webp svg woff2 txt md`。不允许链接、`..` 路径、Windows 保留名，也不允许只有大小写不同的重名。

**限额**：最多 1,024 个文件，单个文件 16 MiB，合计 64 MiB；`.vormioplugin` 文件本身不超过 96 MiB。

**权限指纹**：资源库记录的授权覆盖每个扩展点（包括分析器）的 ID、`formats` 与 `companionFormats`。升级时只改代码、名称或版本，授权保持不变；扩大读取范围或新增扩展点后，用户需要重新启用。

## 运行时 API

```ts
import { analyzer, readCompanion, readInput, thumbnail, viewer } from '@vormio/plugin-sdk'

// 查看器：首次与每次换文件时调用；返回即表示已就绪，抛出异常即报告失败。
viewer(async (input, signal) => {
  const bytes = await readInput(input)
  const texture = await readCompanion(input, 'textures/base.png')
  if (texture.status !== 'ok') console.warn(texture.status)
  // …渲染；signal 在换到下一个文件时中止。
})

// 缩略图：返回 Blob、HTMLCanvasElement 或 OffscreenCanvas。
thumbnail(async (input, { maxEdge }) => {
  const canvas = new OffscreenCanvas(maxEdge, maxEdge)
  // …绘制
  return canvas
})

// 分析器：返回这个文件的组成报告，见下一节。
analyzer(async (input) => {
  const gltf = JSON.parse(new TextDecoder().decode(await readInput(input)))
  // …
  return { subresources: [], references: [], diagnostics: [] }
})
```

- `input.url` 是主文件的地址。配套文件按相对地址解析，就像在磁盘上一样：glTF 中的 `textures/a.png` 直接 `fetch(new URL('textures/a.png', input.url))` 即可，加载器也可以直接使用这些地址。地址支持 Range 请求。
- 读取结果：

| 状态            | 含义                                                         | HTTP |
| --------------- | ------------------------------------------------------------ | ---- |
| `ok`            | 读取成功                                                     | 200  |
| `out-of-bounds` | 路径不合法                                                   | 400  |
| `unauthorized`  | 扩展名不在 `companionFormats` 中                             | 403  |
| `over-limit`    | 一次绑定中的配套请求超过 256 次                              | 429  |
| `missing`       | 关联文件夹中没有这个文件，或它被扫描跳过、从库中移除、已缺失 | 404  |
| `changed`       | 文件在磁盘上已变化，与资源库的记录不符                       | 409  |
| `unavailable`   | 其他原因，例如关联文件夹离线或绑定已过期                     | 其他 |

- 不使用这些辅助函数时，页面也可以直接调用 `window.vormio`，接口见 `@vormio/plugin-sdk/bridge` 的 `PluginBridge` 类型。缩略图处理函数返回 PNG 的 `ArrayBuffer`，分析器处理函数（`onAnalyzeRequest`）返回组成报告。
- 插件视图有焦点时，无修饰的 Esc、←、→ 由宿主处理（返回网格、上一个、下一个），插件收不到这三个键。

## 分析器

插件在资源库中启用后，宿主在后台分析它声明的格式：关联与扫描发现新文件或新版本、启用插件、插件代码变化后，匹配的文件进入队列；用户正在查看详情的文件优先，也可以手动“重新分析”。同时最多 2 个分析任务，单个任务 30 秒超时。抛出异常、超时或报告不合格都记为分析失败，并显示原因；同一份插件代码不会对同一个文件版本反复重试。

报告描述被分析文件的一个版本：

```ts
interface CompositionReport {
  /** 文件内部可以定位的对象，最多 10,000 个。 */
  subresources: {
    key: string // 在这个文件版本内唯一，由插件决定，例如 "materials/0"
    kind: string // 显示用的类别，例如 "材质"；宿主只用来分组
    name: string // 显示名称，可以为空串
    parent?: string // 所属子资源的 key，用于显示层级
  }[]
  /** 引用，最多 50,000 条。 */
  references: {
    from?: string // 发起引用的子资源 key；省略表示文件本身
    uri?: string // 指向其他文件：文件中写的原始地址
    key?: string // 指向本文件内的子资源；uri 与 key 恰好给出一个
    role: string // 显示用的角色，例如 "基础色贴图"
    evidence?: string // 在文件中的位置，例如 "/images/2/uri"
  }[]
  /** 分析中发现的问题，最多 500 条。 */
  diagnostics: { severity: 'error' | 'warning' | 'info'; message: string; key?: string }[]
  /** 只完成了部分分析。 */
  partial?: boolean
}
```

- 宿主用 `compositionReportSchema`（`parseReport` 还会检查大小）校验报告，插件可以在返回前用同一份 schema 自查。报告序列化为 JSON 后不超过 4 MiB（按 UTF-8 字节计）；名称与 key 最长 200 字符，类别与角色 80，证据 300，诊断 500，地址 2,048；名称、类别、角色和证据不能含控制字符。
- 重复的 `key`、`parent`/`from`/`key` 指向不存在的子资源、层级成环、`uri` 与 `key` 同时给出或都不给：报告不合格。
- `uri` 原样填写文件里的地址，不要自己解析。宿主解码一次百分号编码，忽略 `?` 与 `#` 之后的部分，把 `\` 当作 `/`，相对于被分析文件解析，再分类：关联文件夹内的文件、越界（`..` 越出关联文件夹）、内嵌（`data:`）、外部（绝对路径、盘符、其他协议）或无效（无法解码、含控制字符、指向目录）。目标文件是否存在由宿主在查询时判定。
- 内嵌数据（`data:`）只需报告到逗号为止的头部，例如 `data:image/png;base64`：宿主只按前缀把它归为内嵌，不保存内容；完整的 `data:` 地址常常超过 2,048 字符，会让整份报告不合格。
- 报告引用不需要读取目标文件，所以不必为了报告引用而声明 `companionFormats`；分析确实要读配套文件时才声明。

## 打包与开发

本包声明了 `"sideEffects": false`：插件页面只用运行时辅助函数时，打包工具（esbuild、Vite、Rollup、webpack）会丢掉 manifest schema 及其依赖的 zod，一个最小页面的运行时代码约 1 KB。Node 端的打包命令与校验从 `@vormio/plugin-sdk/node` 导入。

```bash
npx vormio-plugin pack <构建输出目录> <输出文件.vormioplugin>
```

命令会先校验 manifest 和全部文件，再生成 zip 格式的 `.vormioplugin`；它不会覆盖已有的输出文件。

开发时，在 Vormio 的“插件”页选择“添加开发目录…”，指向构建输出目录。宿主会监听这个目录：每次变化都重新校验，校验通过后重载插件；校验失败时保留上一个有效版本，并在插件卡片上显示错误。Vormio 不执行任何构建命令。

## 插件目录

插件目录是一个签名的 `catalog.json` 加上它列出的插件包，放在静态托管上，Vormio 从这里安装与更新插件。发布方用下面两个命令生成它：

```bash
npx vormio-plugin keygen <密钥路径前缀>
npx vormio-plugin catalog <发布配置.json> --key <私钥.pem> --out <新目录>
```

- `keygen` 生成 Ed25519 密钥对：`<前缀>.private.pem`（PKCS#8）与 `<前缀>.public.txt`（32 字节公钥的 base64，宿主内置这一行）。命令拒绝写进 Git 工作区，也不覆盖已有文件。私钥只在发布者自己的机器上使用，不提交、不上传。
- 发布配置列出新目录收录的全部包，路径相对于配置文件所在的目录：

  ```json
  {
    "previous": "published/3/catalog.json",
    "packages": ["artifacts/model-viewer-0.2.0.vormioplugin"]
  }
  ```

  `previous` 是当前线上的目录，新目录的序号是它的序号加 1，并且它必须由同一把密钥签名。首次发布没有上一版，改用 `"initialSequence": 1`。

- `catalog` 用宿主安装时相同的规则校验每个包，复制为 `packages/<插件 ID>-<版本>-<SHA-256 前 12 位>.vormioplugin`，生成并签名 `catalog.json`，再用公钥复验一遍。输出目录必须是新目录或空目录；任何一项检查失败时都不写出文件。
- 上传时先上传 `packages/`，最后上传 `catalog.json`。`catalog.json` 不要缓存；包的文件名随内容变化，可以长期缓存。

**格式**：`catalog.json` 是一个信封 `{ format: 1, keyId, payload, signature }`。`payload` 是内容的 UTF-8 JSON 的 base64，`signature` 是对这些字节的 Ed25519 签名，`keyId` 是公钥 SHA-256 的前 16 位十六进制。内容是：

```ts
interface CatalogPayload {
  sequence: number // 每次发布加 1；宿主拒绝比已见过的更小的序号
  publishedAt: string // ISO 8601，UTC
  plugins: {
    id: string
    releases: {
      manifest: object // 包内的 manifest.json，原样
      file: string // packages/<名称>.vormioplugin，相对于 catalog.json
      bytes: number
      sha256: string // 整个包文件的 SHA-256，小写十六进制
    }[]
  }[]
}
```

- 限额：`catalog.json` 不超过 1 MiB；最多 256 个插件，每个插件最多 8 个发布；包文件不超过 96 MiB。插件 ID 与同一插件的版本不能重复，`manifest.id` 必须与插件 ID 一致。
- 同一插件可以同时列出给不同 `apiVersion` 宿主的发布。宿主只安装 `apiVersion` 与自己相同、并且 manifest 能通过自己校验的发布，其余显示为需要更新 Vormio。
- 宿主先验签再解析内容；下载的包按 `bytes` 与 `sha256` 核对，再按本地安装的规则校验，包内的 manifest 必须与目录中的一致。

`@vormio/plugin-sdk/node` 同样导出这些功能：`verifyCatalog`、`signCatalog`、`writeCatalog`、`writeCatalogKeys`、`releaseManifest` 与 `compareVersions`。
