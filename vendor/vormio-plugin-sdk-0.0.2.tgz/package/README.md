# @vormio/plugin-sdk

为 Vormio 编写插件所需的 manifest schema、运行时辅助函数与打包命令。本包随 Vormio-Core 同版本发布（当前 0.0.2），以 tarball 交付，不发布到 npm。

插件契约版本 `apiVersion: 1`。开发期（0.0.x）不承诺跨版本兼容：宿主只加载与自己相同 `apiVersion` 的插件。

## 插件能做什么

插件为它声明的格式提供两种能力：

| 扩展点 | 运行位置                               | 结果                                                                                     |
| ------ | -------------------------------------- | ---------------------------------------------------------------------------------------- |
| 缩略图 | 隐藏的沙箱页面，可以用 Canvas 与 WebGL | 一张 PNG，最长边不超过宿主给出的 `maxEdge`（目前 320），宿主再限制在 512×512、4 MiB 以内 |
| 查看器 | 叠在 Vormio 查看区上的沙箱页面         | 只读地显示文件，用户可以在其中交互                                                       |

插件在资源库中启用后才会运行。每个插件有自己的内存分区：

- 不能访问网络、`file:` 或其他插件。
- 没有 Node，不能用 `eval`。
- 可以使用 WebAssembly 与 Worker。
- 只能读取宿主绑定给它的文件，以及同一关联文件夹中、扩展名在 `companionFormats` 里的配套文件。
- 不能修改任何文件。

## 包结构

一个插件是一个目录：根目录下的 `manifest.json` 加上构建好的静态文件。

```json
{
  "apiVersion": 1,
  "id": "acme.model-viewer",
  "version": "0.1.0",
  "name": "模型查看器",
  "description": "示例。",
  "contributions": {
    "thumbnails": [
      {
        "id": "model",
        "entry": "thumbnail.html",
        "formats": ["gltf", "glb"],
        "companionFormats": ["bin", "png", "jpg"]
      }
    ],
    "viewers": [
      {
        "id": "model",
        "entry": "viewer.html",
        "formats": ["gltf", "glb"],
        "companionFormats": ["bin", "png", "jpg"]
      }
    ]
  }
}
```

- `id` 为 `发布者.名称`，只用小写字母、数字与连字符；`vormio` 发布者保留给宿主。
- `formats`、`companionFormats` 是不带点的小写扩展名，不能用通配符。
- `entry` 是包内的 HTML 文件。页面带有严格的内容安全策略，脚本必须放在单独的文件里，不能内联。
- 未知字段会被拒绝。

**允许的文件**：`html js mjs css json wasm png jpg jpeg webp svg woff2 txt md`。不允许链接、`..` 路径、Windows 保留名，也不允许只有大小写不同的重名。

**限额**：最多 1,024 个文件，单个文件 16 MiB，合计 64 MiB。

**权限指纹**：资源库记录的授权覆盖每个扩展点的 ID、`formats` 与 `companionFormats`。升级时只改代码、名称或版本，授权保持不变；扩大读取范围后，用户需要重新启用。

## 运行时 API

```ts
import { readCompanion, readInput, thumbnail, viewer } from '@vormio/plugin-sdk'

// 查看器：首次与每次换文件时调用；返回即表示已就绪，抛出异常即报告失败。
viewer(async (input, signal) => {
  const bytes = await readInput(input)
  const texture = await readCompanion(input, 'textures/base.png')
  if (texture.status !== 'ok') console.warn(texture.status)
  // …渲染；signal 在换到下一个文件时中止。
})

// 缩略图：返回 Blob、HTMLCanvasElement 或 OffscreenCanvas。
thumbnail(async (input, { maxEdge }) => {
  const canvas = new OffscreenCanvas(maxEdge, maxEdge)
  // …绘制
  return canvas
})
```

- `input.url` 是主文件的地址。配套文件按相对地址解析，就像在磁盘上一样：glTF 中的 `textures/a.png` 直接 `fetch(new URL('textures/a.png', input.url))` 即可，加载器也可以直接使用这些地址。地址支持 Range 请求。
- 读取结果：

| 状态            | 含义                                                         | HTTP |
| --------------- | ------------------------------------------------------------ | ---- |
| `ok`            | 读取成功                                                     | 200  |
| `out-of-bounds` | 路径不合法                                                   | 400  |
| `unauthorized`  | 扩展名不在 `companionFormats` 中                             | 403  |
| `over-limit`    | 一次绑定中的配套请求超过 256 次                              | 429  |
| `missing`       | 关联文件夹中没有这个文件，或它被扫描跳过、从库中移除、已缺失 | 404  |
| `changed`       | 文件在磁盘上已变化，与资源库的记录不符                       | 409  |
| `unavailable`   | 其他原因，例如关联文件夹离线或绑定已过期                     | 其他 |

- 不使用这些辅助函数时，页面也可以直接调用 `window.vormio`，接口见 `@vormio/plugin-sdk/bridge` 的 `PluginBridge` 类型。缩略图处理函数返回 PNG 的 `ArrayBuffer`。
- 插件视图有焦点时，无修饰的 Esc、←、→ 由宿主处理（返回网格、上一个、下一个），插件收不到这三个键。

## 打包与开发

```bash
npx vormio-plugin pack <构建输出目录> <输出文件.vormioplugin>
```

命令会先校验 manifest 和全部文件，再生成 zip 格式的 `.vormioplugin`；它不会覆盖已有的输出文件。

开发时，在 Vormio 的“插件”页选择“添加开发目录…”，指向构建输出目录。宿主会监听这个目录：每次变化都重新校验，校验通过后重载插件；校验失败时保留上一个有效版本，并在插件卡片上显示错误。Vormio 不执行任何构建命令。
