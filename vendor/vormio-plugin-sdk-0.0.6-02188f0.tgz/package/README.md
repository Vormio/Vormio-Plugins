# @vormio/plugin-sdk

The manifest schema, runtime helpers and packaging command for writing Vormio plugins, plus the commands that publish a signed plugin catalog. The package is versioned with Vormio-Core (currently 0.0.6) and published to npm under the MIT license: `npm install @vormio/plugin-sdk@0.0.6`.

Plugin contract version: `apiVersion: 2`. During development (0.0.x) there is no cross-version compatibility promise: the host loads only plugins with the same `apiVersion` as its own.

## What a plugin can do

A plugin provides three capabilities for the formats it declares. They are independent: declaring one does not grant the others.

| Extension point | Runs in                                        | Result                                                                                                                       |
| --------------- | ---------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| Thumbnail       | A hidden sandboxed page; Canvas and WebGL work | One PNG whose longest edge is at most the host's `maxEdge` (currently 320); the host then caps it at 512×512 and 4 MiB       |
| Viewer          | A sandboxed page over Vormio's viewing area    | Shows the file read-only; the user can interact with it                                                                      |
| Analyzer        | A hidden sandboxed page                        | A composition report: the file's internal subresources, the files it references and diagnostics; see [Analyzers](#analyzers) |

A plugin runs only after it is enabled in a library. Each plugin has its own memory partition:

- No access to the network, `file:` or other plugins.
- No Node and no `eval`.
- WebAssembly and Workers are available.
- It can read only the file the host binds to it, plus companion files in the same linked folder whose extensions are listed in `companionFormats`.
- It cannot modify any file.

## Package layout

A plugin is a folder: a `manifest.json` at the root plus the built static files.

```json
{
  "apiVersion": 2,
  "id": "acme.model-viewer",
  "version": "0.1.0",
  "name": "Model Viewer",
  "description": "Example.",
  "contributions": {
    "thumbnails": [
      {
        "id": "model",
        "entry": "thumbnail.html",
        "formats": ["gltf", "glb"],
        "companionFormats": ["bin", "png", "jpg"]
      }
    ],
    "viewers": [
      {
        "id": "model",
        "entry": "viewer.html",
        "formats": ["gltf", "glb"],
        "companionFormats": ["bin", "png", "jpg"]
      }
    ],
    "analyzers": [{ "id": "model", "entry": "analyzer.html", "formats": ["gltf", "glb"] }]
  }
}
```

- `thumbnails`, `viewers` and `analyzers` are each optional, but there must be at least one extension point. Each kind allows up to 8, with unique IDs within the kind.
- `id` is `publisher.name`, using only lowercase letters, digits and hyphens. The `vormio` publisher is reserved for the host.
- `formats` and `companionFormats` are lowercase extensions without the dot. Wildcards are not allowed.
- `entry` is an HTML file in the package. Pages run under a strict Content Security Policy: scripts must be separate files, not inline.
- Unknown fields are rejected.

**Allowed files**: `html js mjs css json wasm png jpg jpeg webp svg woff2 txt md`. Links, `..` paths, Windows reserved names and names that differ only by case are not allowed.

**Limits**: at most 1,024 files, 16 MiB per file and 64 MiB in total; the `.vormioplugin` file itself is at most 96 MiB.

**Grants**: a library records what the user approved for each extension point (analyzers included): its ID, `formats` and `companionFormats`. A version that reads no more than that keeps running without asking again, including:

- an upgrade that changes only code, name or version
- an upgrade that reads less
- a rollback

Reading more formats or companion formats, or adding an extension point, requires the user to enable the plugin again, and that approval is added to what was approved before.

## Runtime API

```ts
import { analyzer, readCompanion, readInput, thumbnail, viewer } from '@vormio/plugin-sdk'

// Viewer: called first and on every file change. Returning means ready; throwing reports a failure;
// returning notApplicable() hands the file to the next viewer (see below).
viewer(async (input, signal) => {
  const bytes = await readInput(input)
  const texture = await readCompanion(input, 'textures/base.png')
  if (texture.status !== 'ok') console.warn(texture.status)
  // …render; signal aborts when the viewer moves to the next file.
})

// Thumbnail: return a Blob, HTMLCanvasElement or OffscreenCanvas.
thumbnail(async (input, { maxEdge }) => {
  const canvas = new OffscreenCanvas(maxEdge, maxEdge)
  // …draw
  return canvas
})

// Analyzer: return the file's composition report; see the next section.
analyzer(async (input) => {
  const gltf = JSON.parse(new TextDecoder().decode(await readInput(input)))
  // …
  return { subresources: [], references: [], diagnostics: [] }
})
```

- `input.url` is the main file's address. Companion files resolve by relative address, just as on disk: for `textures/a.png` in a glTF, `fetch(new URL('textures/a.png', input.url))` works, and loaders can use these addresses directly. The addresses support Range requests.
- Read results:

| Status          | Meaning                                                                                                     | HTTP  |
| --------------- | ----------------------------------------------------------------------------------------------------------- | ----- |
| `ok`            | Read succeeded                                                                                              | 200   |
| `out-of-bounds` | Invalid path                                                                                                | 400   |
| `unauthorized`  | The extension is not in `companionFormats`                                                                  | 403   |
| `over-limit`    | More than 256 companion requests in one binding                                                             | 429   |
| `missing`       | The file is not in the linked folder, or it was skipped by the scan, removed from the library or is missing | 404   |
| `changed`       | The file changed on disk and no longer matches the library's record                                         | 409   |
| `unavailable`   | Any other reason, such as an offline linked folder or an expired binding                                    | Other |

- Pages that do not use these helpers can call `window.vormio` directly; see the `PluginBridge` type in `@vormio/plugin-sdk/bridge`. A thumbnail handler returns the PNG as an `ArrayBuffer`, and an analyzer handler (`onAnalyzeRequest`) returns the composition report; either can return `{ notApplicable: true }` instead, and a viewer calls `notApplicable(input)`.
- While a plugin view has focus, unmodified Esc, ← and → are handled by the host (back to the grid, previous, next); the plugin does not receive these keys.

## Files that are not your format

The host chooses plugins by extension only. When a format you declare is shared with other tools, such as `json`, every file with that extension comes to you. Return `notApplicable()` for the files that are not yours:

```ts
import { analyzer, notApplicable, readInput, thumbnail, viewer } from '@vormio/plugin-sdk'

analyzer(async (input) => {
  const data = JSON.parse(new TextDecoder().decode(await readInput(input)))
  if (!isSkeleton(data)) return notApplicable()
  return analyzeSkeleton(data)
})
```

`thumbnail()` and `viewer()` accept the same answer.

- It is not a failure. The host records no reason and shows nothing for it:
  - an analyzer's file gets no composition section;
  - thumbnails and viewers move on to the next enabled plugin for the format, then to the built-in preview or the type icon.
- The host asks each extension point about each file version once. It asks again when the file changes or your plugin's code changes, so a plugin loaded from a development folder is asked again after every reload.
- Decide from the file alone; companion files read before answering are not tracked. Decide from the start of the file when you can (the input supports Range requests): a viewer's user waits for the answer before seeing the built-in preview.
- A file that is your format but has a problem should throw, or report diagnostics, so the user sees why.
- When several enabled plugins declare a format, the host asks them in order of plugin ID. Thumbnails and viewers ask the next one after a `notApplicable()`; analyzers ask only the first.

## Analyzers

Once a plugin is enabled in a library, the host analyzes its declared formats in the background. Matching files join the queue when linking and scanning find new files or versions, when the plugin is enabled, and when the plugin's code changes. The file whose details the user is viewing goes first, and the user can also re-analyze manually. At most 2 analyses run at once, each with a 30-second timeout. A thrown error, a timeout or an invalid report counts as a failed analysis and shows the reason; the same plugin code is not retried on the same file version. For files that are not your format, return `notApplicable()` (see [Files that are not your format](#files-that-are-not-your-format)).

A report describes one version of the analyzed file:

```ts
interface CompositionReport {
  /** Locatable objects inside the file, at most 10,000. */
  subresources: {
    key: string // Unique within this file version, chosen by the plugin, e.g. "materials/0"
    kind: string // Display category, e.g. "Material"; the host uses it only for grouping
    name: string // Display name; may be an empty string
    parent?: string // Key of the parent subresource, for display hierarchy
  }[]
  /** References, at most 50,000. */
  references: {
    from?: string // Key of the referencing subresource; omitted means the file itself
    uri?: string // Points to another file: the raw address written in the file
    key?: string // Points to a subresource in this file; give exactly one of uri and key
    role: string // Display role, e.g. "Base color texture"
    evidence?: string // Location in the file, e.g. "/images/2/uri"
  }[]
  /** Problems found during analysis, at most 500. */
  diagnostics: { severity: 'error' | 'warning' | 'info'; message: string; key?: string }[]
  /** Only part of the analysis completed. */
  partial?: boolean
}
```

- The host validates reports with `compositionReportSchema` (`parseReport` also checks the size); plugins can check themselves against the same schema before returning. The report serialized as JSON is at most 4 MiB (counted in UTF-8 bytes). Names and keys are at most 200 characters, kinds and roles 80, evidence 300, diagnostics 500 and addresses 2,048. Names, kinds, roles and evidence must not contain control characters.
- The report is invalid if it has duplicate keys, a `parent`, `from` or `key` that points to a missing subresource, a cyclic hierarchy, or a reference with both or neither of `uri` and `key`.
- Write `uri` exactly as it appears in the file; do not resolve it yourself. The host decodes percent-encoding once, ignores everything after `?` and `#`, treats `\` as `/`, resolves it relative to the analyzed file and classifies it: a file in the linked folder, out of bounds (`..` leaving the linked folder), embedded (`data:`), external (absolute paths, drive letters, other schemes) or invalid (undecodable, containing control characters, or pointing to a folder). Whether the target exists is decided by the host at query time.
- For embedded data (`data:`), report only the header up to the comma, e.g. `data:image/png;base64`. The host classifies it as embedded by prefix and does not store the content; a full `data:` address often exceeds 2,048 characters and would invalidate the whole report.
- Reporting a reference does not require reading the target file, so you do not need `companionFormats` just to report references. Declare them only when the analysis actually reads companion files.

## Packaging and development

The package declares `"sideEffects": false`: when a plugin page uses only the runtime helpers, bundlers (esbuild, Vite, Rollup, webpack) drop the manifest schema and its zod dependency, leaving about 1 KB of runtime code for a minimal page. Node-side packaging and validation are imported from `@vormio/plugin-sdk/node`.

```bash
npx vormio-plugin pack <build-output-folder> <output-file.vormioplugin>
```

The command validates the manifest and every file, then writes a zip-format `.vormioplugin`. It never overwrites an existing output file.

During development, open the **插件** (Plugins) page in Vormio, choose **添加开发目录…** (Add development folder…) and point it at the build output folder. The host watches the folder: every change is validated again, and a valid build reloads the plugin. If validation fails, the last valid version stays loaded and the error is shown on the plugin card. Vormio never runs build commands.

## Plugin catalogs

A plugin catalog is a signed `catalog.json` plus the plugin packages it lists, on static hosting. Vormio installs and updates plugins from it. Publishers produce one with two commands:

```bash
npx vormio-plugin keygen <key-path-prefix>
npx vormio-plugin catalog <release-config.json> --key <private-key.pem> --out <new-folder>
```

- `keygen` generates an Ed25519 key pair: `<prefix>.private.pem` (PKCS#8) and `<prefix>.public.txt` (the base64 of the 32-byte public key; hosts build this line in). It refuses to write inside a Git working tree and never overwrites a file. The private key stays on the publisher's machine: never commit or upload it.
- The release configuration lists every package in the new catalog, relative to the configuration file:

  ```json
  {
    "previous": "published/3/catalog.json",
    "packages": ["artifacts/model-viewer-0.2.0.vormioplugin"]
  }
  ```

  `previous` is the catalog currently online. The new catalog's sequence is its sequence plus 1, and it must be signed with the same key. A first publication has no previous catalog and uses `"initialSequence": 1` instead.

- `catalog` does the following:
  - Validates every package with the rules a host applies when installing it.
  - Copies each package to `packages/<plugin ID>-<version>-<first 12 hex digits of its SHA-256>.vormioplugin`.
  - Writes and signs `catalog.json`, then verifies it with the public key.

  The output folder must be new or empty. If any check fails, nothing is written.

- Upload `packages/` first and `catalog.json` last. Do not cache `catalog.json`. Package file names change with their content, so packages can be cached for a long time.

**Format**: `catalog.json` is an envelope `{ format: 1, keyId, payload, signature }`:

- `payload` is the base64 of the content's UTF-8 JSON.
- `signature` is the Ed25519 signature of those bytes.
- `keyId` is the first 16 hex digits of the public key's SHA-256.

The content:

```ts
interface CatalogPayload {
  sequence: number // Grows by 1 per publication; hosts refuse a sequence lower than one they have seen
  publishedAt: string // ISO 8601, UTC
  plugins: {
    id: string
    releases: {
      manifest: object // The package's manifest.json, as is
      file: string // packages/<name>.vormioplugin, relative to catalog.json
      bytes: number
      sha256: string // SHA-256 of the whole package file, lowercase hex
    }[]
  }[]
}
```

- Limits:
  - `catalog.json` is at most 1 MiB.
  - At most 256 plugins, with at most 8 releases each.
  - Package files are at most 96 MiB.

  Plugin IDs, and the versions of one plugin, must not repeat. `manifest.id` must match the plugin ID.

- One plugin can list releases for hosts of different `apiVersion`s side by side. A host installs only releases with its own `apiVersion` whose manifest passes its own validation; it shows the rest as needing a newer Vormio.
- Hosts verify the signature before reading the content. A downloaded package must match `bytes` and `sha256`, then pass the rules of a local install, and its manifest must equal the one in the catalog.

`@vormio/plugin-sdk/node` exports the same functionality: `verifyCatalog`, `signCatalog`, `writeCatalog`, `writeCatalogKeys`, `releaseManifest` and `compareVersions`.
